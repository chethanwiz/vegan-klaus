/// Google service API key used for Place Autocomplete
const String googleMapApiKey = 'xxxxxxxxxxxxxx';
