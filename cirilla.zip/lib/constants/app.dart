const String baseUrl = 'https://yourdomain.com/';

const String consumerKey = 'ck_xxxxxxxxxxxxxxxxxx';

const String consumerSecret = 'cs_xxxxxxxxxxxxxxx';

const String restPrefix = 'wp-json';

const String defaultLanguage = 'en';

const List<String> languageSupport = ['en', 'ar', 'tr'];

const String googleClientId = '295269595518-e7s01ueadskq7sbg2k4g4dfnefpmd7vt.apps.googleusercontent.com';
