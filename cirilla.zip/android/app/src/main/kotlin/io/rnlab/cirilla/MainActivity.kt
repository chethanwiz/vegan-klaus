package io.rnlab.cirilla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
